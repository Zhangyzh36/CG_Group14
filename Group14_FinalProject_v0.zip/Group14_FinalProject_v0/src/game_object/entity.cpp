#include "Entity.h"

glm::mat4 Entity::getModelMat() const {
  return glm::mat4(1.0f);
}